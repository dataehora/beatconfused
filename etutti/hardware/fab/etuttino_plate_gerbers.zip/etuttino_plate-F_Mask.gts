%TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*%
%TF.CreationDate,2026-10-14T12:31:09+01:00*%
%TF.ProjectId,etuttino_plate,65747574-7469-46e6-9f5f-706c6174652e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-14 12:31:09*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
