%TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*%
%TF.CreationDate,2026-10-11T00:56:13+01:00*%
%TF.ProjectId,etuttino_plate,65747574-7469-46e6-9f5f-706c6174652e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-11 00:56:13*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H6*%
X180450000Y-129199999D03*
%TD*%
%TO.C,H10*%
X172687500Y-78575000D03*
%TD*%
%TO.C,H4*%
X180450000Y-47000000D03*
%TD*%
%TO.C,H7*%
X10762500Y-116675000D03*
%TD*%
%TO.C,H8*%
X172687500Y-116675000D03*
%TD*%
%TO.C,H9*%
X10762500Y-78575000D03*
%TD*%
%TO.C,H3*%
X3000000Y-47000000D03*
%TD*%
%TO.C,H5*%
X3000000Y-129199999D03*
%TD*%
M02*
