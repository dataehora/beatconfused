%TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*%
%TF.CreationDate,2026-10-12T08:00:55+01:00*%
%TF.ProjectId,etuttino_plate,65747574-7469-46e6-9f5f-706c6174652e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-12 08:00:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H5*%
X237600000Y-85200000D03*
%TD*%
%TO.C,H4*%
X237600000Y-48019999D03*
%TD*%
%TO.C,H2*%
X3000000Y-85200000D03*
%TD*%
%TO.C,H7*%
X10762500Y-34575000D03*
%TD*%
%TO.C,H3*%
X222675000Y-3000000D03*
%TD*%
%TO.C,H9*%
X220612500Y-15525000D03*
%TD*%
%TO.C,H6*%
X10762500Y-72675000D03*
%TD*%
%TO.C,H1*%
X3000000Y-3000000D03*
%TD*%
%TO.C,H8*%
X234600000Y-72675000D03*
%TD*%
M02*
