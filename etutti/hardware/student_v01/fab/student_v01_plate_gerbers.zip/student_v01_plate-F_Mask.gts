%TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*%
%TF.CreationDate,2026-11-15T13:12:11+00:00*%
%TF.ProjectId,student_v01_plate,73747564-656e-4745-9f76-30315f706c61,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-11-15 13:12:11*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H5*%
X98450000Y-52670000D03*
%TD*%
%TO.C,H7*%
X153950000Y-63350000D03*
%TD*%
%TO.C,H8*%
X209450000Y-52670000D03*
%TD*%
%TO.C,H6*%
X153950000Y-31310000D03*
%TD*%
M02*
